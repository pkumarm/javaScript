$(document).ready(function(){
   $(".profile_ttl_child").click(function(){
      $(this).find(".profile_cnt").toggleClass("profile_cnt_display");
    });
});
